#include <stdio.h>
#include <string.h>

int main ()
{


	char seq[1000];
	int len;

	scanf("%s", seq);


	len = strlen(seq);

	printf("The lenght of the sequence is : %d \n ", len);



	if( len < 5 )
	{

		 printf("EISAI BOYBOYNAS!!!!!! \n" );	


	}


	

}

