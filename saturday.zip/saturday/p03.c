#include <stdio.h>


int main ()
{

	char seq[1000];
	scanf("%s", seq);

	

	printf("The first aa is : %c \n ", seq [ 0 ] );
	printf("The second aa is : %c \n ", seq [ 1 ] );

}

