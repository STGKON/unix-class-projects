#include <stdio.h>
#include <string.h>
# include <stdlib.h>
int main ()
{


	char seq[1000];
	int len;
	int i;
	int charge = 0;

while(1)
{
	scanf("%s", seq);


	len = strlen(seq);

	printf("The lenght of the sequence is : %d \n ", len);



	if( len < 5 )
	{

		 printf("EISAI BOYBOYNAS!!!!!! \n" );	
	

		exit(1);

	}

		




	for( i=0; i < len ; i++)
	{

	if(seq[i]== 'K' || seq[i]=='R')
		{
			charge ++;		
		
		}

	if(seq[i]== 'D' || seq[i]=='E')
		{

			charge --;
		}

	}	

		printf("The total amount of charge is %d \n", charge);
		charge =0;




}	

}

