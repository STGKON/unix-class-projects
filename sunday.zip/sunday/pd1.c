#include <stdio.h>
#include <string.h>
# include <stdlib.h>
int main ()
{


	char seq[1000];
	int len;
	int i;



	scanf("%s", seq);
	len = strlen(seq);
	printf("The lenght of the sequence is : %d \n ", len);



	if( len < 3 )
		{
			 printf("EISAI BOYBOYNAS!!!!!! \n" );
	  		exit(1);
		}









	if(	   seq[0]== 'A' &&
		   seq[1]== 'T' &&
		   seq[2]== 'C'   )

		printf(" ATC IS HERE !\n" );
		

	else
		{
		printf("ATC IS NOT HERE\n");
		}





}

